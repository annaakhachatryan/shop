import { configureStore } from "@reduxjs/toolkit";
import { gameDataReducer } from "./slices/gameSlice/gameSlice";

const store = configureStore({
    reducer:{
        gamesData: gameDataReducer,
    },
    middleware:(getDefaultMiddleware) => [...getDefaultMiddleware()]
})

export default store