import { createSlice } from "@reduxjs/toolkit";
import { fetchComments, fetchGame, fetchGameComments, fetchGameData, fetchGameUser, fetchUSer } from "./gameSliceAPI";

const gameDataSlice = createSlice({
    name: 'gamesData',
    initialState: {
        gameItem: [],
        game: {},
        commentsItem: [],
        comments: {},
        usersItem: [],
        user: {}
    },
    reducers: {
        incrementLikes(state) {
            state.game.likes++;
        },
        decrementLikes(state) {
            if (state.game.likes > 0) {
                state.game.likes--;
        }
        }
    },
    extraReducers: {
        [fetchGameData.fulfilled]: (state, { payload }) => {
            state.gameItem = payload;
        },
        [fetchGame.fulfilled]: (state, { payload }) => {
            state.game = payload;
        },
        [fetchGameComments.fulfilled]: (state, { payload }) => {
            state.commentsItem = payload;
        },
        [fetchComments.fulfilled]: (state, { payload }) => {
            state.comments = payload;
        },
        [fetchGameUser.fulfilled]: (state, { payload }) => {
            state.usersItem = payload;
        },
        [fetchUSer.fulfilled]: (state, { payload }) => {
            state.user = payload;
        },
    }
});

export const selectGameDataSlice = state => state.gamesData;

export const { incrementLikes, decrementLikes } = gameDataSlice.actions;
export const gameDataReducer = gameDataSlice.reducer;
