import React from 'react'

export const IgriSanalogm = () => {
    return (
        <div>IgriSanalogm</div>
    )
}
